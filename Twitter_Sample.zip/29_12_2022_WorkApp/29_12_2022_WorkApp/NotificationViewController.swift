//
//  NotificationViewController.swift
//  29_12_2022_WorkApp
//
//  Created by Anil Kumar on 29/12/22.
//

import UIKit
import SideMenu
class Responder: NSObject {
    @objc func segmentedControlValueChanged(_ sender: UISegmentedControl) {

    }
}


var flag = 0
var halfsegment = 0
class NotificationViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
  @IBOutlet weak var backView: UIView!
  @IBOutlet weak var headingLabel: UILabel!
  
  @IBOutlet weak var allAndMentionSegment: UISegmentedControl!
  
 
  
  @IBOutlet weak var addFolder: UIButton!
  
  @IBOutlet weak var itemsTableView: UITableView!
  @IBOutlet weak var profilePic: UIImageView!
  let buttonBar = UIView()
  override func viewDidLoad() {
        super.viewDidLoad()
    
    
    
    allAndMentionSegment.addUnderlineForSelectedSegment()
    let responder = Responder()

    
    let attr = [NSAttributedString.Key.font: UIFont(name: "Hiragino Sans", size: 19.0)!]
    UISegmentedControl.appearance().setTitleTextAttributes(attr, for: UIControl.State.normal)
    
    itemsTableView.delegate = self
    itemsTableView.dataSource = self
    
    profilePic.layer.cornerRadius = 20
    profilePic.clipsToBounds = true
    
    
    addFolder.layer.cornerRadius = 25
    addFolder.clipsToBounds = true

    
    allAndMentionSegment.addTarget(self, action: #selector(NotificationViewController.indexChanged(_:)), for: .valueChanged)
    
    
    allAndMentionSegment.addTarget(responder, action: #selector(responder.segmentedControlValueChanged(_:)), for: UIControl.Event.valueChanged)
        // Do any additional setup after loading the view.
    }
  
  @objc func indexChanged(_ sender: UISegmentedControl) {
      if allAndMentionSegment.selectedSegmentIndex == 0 {
        
        flag = 0
        headingLabel.text = "Notifications"
//        itemsTableView.separatorStyle = .singleLine
        itemsTableView.reloadData()
        
        
          
      } else if allAndMentionSegment.selectedSegmentIndex == 1 {
          flag = 1
        headingLabel.text = "Mentions"
//        itemsTableView.separatorStyle = .none
        itemsTableView.reloadData()
        
        
      }
  }
  
  @objc func segmentedControlValueChanged(_ sender: UISegmentedControl) {
   
    allAndMentionSegment.changeUnderlinePosition()
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
   var rowCount = 0
    if(flag == 0){
      rowCount = 3
      
    }
        else{
      rowCount = 15
    }
    return rowCount
  }
  
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    var rowHeight = 0.0
    
    if(flag==0)
    {
      rowHeight = 98
    }
    else{
      rowHeight = 75
    }
    return rowHeight
  }
  
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    
    if(flag==0)
    {
      addFolder.setImage(UIImage(systemName: "plus"), for: .normal)
      let cell = itemsTableView.dequeueReusableCell(withIdentifier: "allItemsTableViewCell", for: indexPath) as! allItemsTableViewCell
      
      cell.contentView.clipsToBounds = false
      cell.contentView.layer.cornerRadius = 15
      cell.contentView.backgroundColor = UIColor(red: 247.0/255, green: 247.0/255, blue: 247.0/255, alpha: 1.0)
    if indexPath.row == 0
    {
    
    
      profilePics = ["Alex","Bob","Katie","Ash"]
      cell.likeAndFollowLabel.text = "Alex and 4 others like you"
      cell.tagLineLabel.text = "Friends can break your heart"
    }
    if indexPath.row == 1
    {
      profilePics = ["Zach","Chloe"]
      cell.likeAndFollowLabel.text = "Zach and 3 others followed you"
      cell.tagLineLabel.text = ""
    }
    else
    {
      profilePics = ["Tara","Zen","Alex"]
      cell.likeAndFollowLabel.text = "Tara and 5 others liked your tweet"
      cell.tagLineLabel.text = "No one knows what you feel inside"
    }
   
      return cell
 
    }
    
    else
    {
      addFolder.setImage(UIImage(systemName: "folder.fill.badge.plus"), for: .normal)
   
      
      
      
     let cell2 = itemsTableView.dequeueReusableCell(withIdentifier: "allItemsTableViewCell2") as! allItemsTableViewCell2TableViewCell
      
      cell2.msgeContact.text = "Potato"
      cell2.msgeTExt.text = "Hey"
      cell2.msgeMention.text = "@Potato"
      cell2.msgeMention.textColor = .gray
      cell2.msgeTime.text = "2h"
      cell2.msgeTime.textColor = .gray
      cell2.msgeProfile.image = UIImage(named: "Alex")
      cell2.msgeProfile.clipsToBounds = true
      cell2.msgeProfile.layer.cornerRadius = 25
      
      return cell2

    }
    
  }
    
  
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UISegmentedControl{
    func removeBorder(){
        let backgroundImage = UIImage.getColoredRectImageWith(color: UIColor.white.cgColor, andSize: self.bounds.size)
        self.setBackgroundImage(backgroundImage, for: .normal, barMetrics: .default)
        self.setBackgroundImage(backgroundImage, for: .selected, barMetrics: .default)
        self.setBackgroundImage(backgroundImage, for: .highlighted, barMetrics: .default)

        let deviderImage = UIImage.getColoredRectImageWith(color: UIColor.white.cgColor, andSize: CGSize(width: 1.0, height: self.bounds.size.height))
        self.setDividerImage(deviderImage, forLeftSegmentState: .selected, rightSegmentState: .normal, barMetrics: .default)
      self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for: .normal)
      self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor(red: 67/255, green: 129/255, blue: 244/255, alpha: 1.0)], for: .selected)
    }

    func addUnderlineForSelectedSegment(){
        removeBorder()
        let underlineWidth: CGFloat = self.bounds.size.width / CGFloat(self.numberOfSegments)
        let underlineHeight: CGFloat = 2.0
        let underlineXPosition = CGFloat(selectedSegmentIndex * Int(underlineWidth))
        let underLineYPosition = self.bounds.size.height - 1.0
        let underlineFrame = CGRect(x: underlineXPosition, y: underLineYPosition, width: underlineWidth, height: underlineHeight)
        let underline = UIView(frame: underlineFrame)
        underline.backgroundColor = UIColor(red: 67/255, green: 129/255, blue: 244/255, alpha: 1.0)
        underline.tag = 1
        self.addSubview(underline)
    }

    func changeUnderlinePosition(){
        guard let underline = self.viewWithTag(1) else {return}
        let underlineFinalXPosition = (self.bounds.width / CGFloat(self.numberOfSegments)) * CGFloat(selectedSegmentIndex)
        UIView.animate(withDuration: 0.3, animations: {
            underline.frame.origin.x = underlineFinalXPosition
        })
    }
}

extension UIImage{

    class func getColoredRectImageWith(color: CGColor, andSize size: CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        let graphicsContext = UIGraphicsGetCurrentContext()
        graphicsContext?.setFillColor(color)
        let rectangle = CGRect(x: 0.0, y: 0.0, width: size.width, height: size.height)
        graphicsContext?.fill(rectangle)
        let rectangleImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return rectangleImage!
    }
}





