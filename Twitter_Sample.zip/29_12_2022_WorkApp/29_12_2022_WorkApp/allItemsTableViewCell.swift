//
//  allItemsTableViewCell.swift
//  29_12_2022_WorkApp
//
//  Created by Anil Kumar on 30/12/22.
//

import UIKit

class allItemsTableViewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
  
  


  @IBOutlet weak var tagLineLabel: UILabel!
  @IBOutlet weak var likeAndFollowLabel: UILabel!
  @IBOutlet weak var profileCollectionView: UICollectionView!


  
  override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    dataSourceArr = ["Change Password","Logout"]
    profileCollectionView.delegate = self
    profileCollectionView.dataSource = self
    
   
    
    
  
   
    }
  override func layoutSubviews() {
      super.layoutSubviews()

      contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 5, left: 5, bottom: 0, right: 5))
  }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

  
  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    
      return profilePics.count

  }
  
  func numberOfSections(in collectionView: UICollectionView) -> Int {
   
    return 1
  }
  
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
   
    let cell = profileCollectionView.dequeueReusableCell(withReuseIdentifier: "profilesCollectionViewCell", for: indexPath) as! profilesCollectionViewCell
    
    let val = profilePics[indexPath.row]
    
    cell.picImage.image = UIImage(named: val as String)
    cell.picImage.frame = CGRect(x: 0, y:0, width: 30, height: 30)
    
    cell.picImage.clipsToBounds = true
    cell.layer.cornerRadius = 15
    
    
    
    return cell
  }
  
  func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
    return CGSize(width: 30.0, height: 30.0)
  }
  

}
