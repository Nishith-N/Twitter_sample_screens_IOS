//
//  profilesCollectionViewCell.swift
//  29_12_2022_WorkApp
//
//  Created by Anil Kumar on 30/12/22.
//

import UIKit

class profilesCollectionViewCell: UICollectionViewCell {
    
  @IBOutlet weak var picImage: UIImageView!
  
  
}
