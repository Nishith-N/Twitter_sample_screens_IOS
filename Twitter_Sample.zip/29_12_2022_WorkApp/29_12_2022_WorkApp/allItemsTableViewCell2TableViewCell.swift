//
//  allItemsTableViewCell2TableViewCell.swift
//  29_12_2022_WorkApp
//
//  Created by Anil Kumar on 30/12/22.
//

import UIKit

class allItemsTableViewCell2TableViewCell: UITableViewCell {

  @IBOutlet weak var msgeTime: UILabel!
  @IBOutlet weak var msgeMention: UILabel!
  @IBOutlet weak var msgeTExt: UILabel!
  @IBOutlet weak var msgeContact: UILabel!
  @IBOutlet weak var msgeProfile: UIImageView!
  override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
