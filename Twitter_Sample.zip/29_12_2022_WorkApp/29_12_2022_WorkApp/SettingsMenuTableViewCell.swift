//
//  SettingsMenuTableViewCell.swift
//  29_12_2022_WorkApp
//
//  Created by Anil Kumar on 30/12/22.
//

import UIKit

class SettingsMenuTableViewCell: UITableViewCell {

  @IBOutlet weak var menuLabel: UILabel!
  @IBOutlet weak var iconImage: UIImageView!
  override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
