//
//  SettingsSIdeMenuViewController.swift
//  29_12_2022_WorkApp
//
//  Created by Anil Kumar on 30/12/22.
//

import UIKit
import SideMenu


class SettingsSideMenuViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
  
  
  
  @IBOutlet weak var settingsMenuTableView: UITableView!
  override func viewDidLoad() {
        super.viewDidLoad()
    
    settingsMenuTableView.delegate = self
    settingsMenuTableView.dataSource = self
    dataSourceArr = ["power.circle.fill","lock.fill"]
    dataSourceArr2 = ["Logout","Change Password"]
    
    
    
      

        // Do any additional setup after loading the view.
    }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return dataSourceArr.count
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 60
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = settingsMenuTableView.dequeueReusableCell(withIdentifier: "SettingsMenuTableViewCell", for: indexPath) as! SettingsMenuTableViewCell
    
    let val = dataSourceArr[indexPath.row]
    
    
    cell.iconImage.image = UIImage(systemName: val )
    cell.menuLabel.text = dataSourceArr2[indexPath.row]
    
    return cell
    
  }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
