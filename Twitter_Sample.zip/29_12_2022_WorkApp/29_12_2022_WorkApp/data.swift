//
//  data.swift
//  29_12_2022_WorkApp
//
//  Created by Anil Kumar on 30/12/22.
//

import Foundation


var profilePics = Array<String>()
var profilePic2 = Array<String>()
var dataSourceArr = Array<String>()
var dataSourceArr2 = Array<String>()


//      cell.likeAndFollowLabel.isHidden = true
//      cell.tagLineLabel.isHidden = true
//      cell.profileCollectionView.isHidden = true

//      cell.msgeText.isHidden = false
//      cell.msgeName.isHidden = false
//      cell.tagLineLabel.isHidden = false
//      cell.msgeTime.isHidden = false
//      cell.msgeMention.isHidden = false
//
//      cell.profimage.image = UIImage(named: "Alex")
//      cell.contacts.text = "Alex"
//      cell.mentionCont.text = "@potato"
//      cell.timelbl.text = "2h"
//      cell.msge.text = "Hey"
